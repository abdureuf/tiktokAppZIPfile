This TikTok flutter clone was done by 4th year BDU software engineering students.
                        
Abeselom solomon                 1200738
Ademe    Cheklie                 1200808
